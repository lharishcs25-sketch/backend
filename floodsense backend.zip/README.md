# FloodSense Bengaluru — MERN Backend (`Express + MongoDB + Node + Socket.IO`)

Hyperlocal urban flood monitoring, AI-based flooding time & pothole depth estimation, live weather telemetry, and **area-isolated real-time alerts** for Bengaluru hotspots (**Bellandur, HSR Layout, Whitefield, Koramangala, Silk Board / BTM, Marathahalli**).

---

## 1. Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment variables
cp .env.example .env

# 3. Seed Bengaluru areas, streets, potholes & initial reports into MongoDB
npm run seed

# 4. Run the server (with Socket.IO)
npm run dev
```

Server starts at `http://localhost:5000`.

---

## 2. Core Features Built for Your Frontend

1. **Area Selection & Street Directory (`GET /api/areas`, `GET /api/areas/:slug`)**
   - Returns all supported Bengaluru zones and detailed street-level telemetry (drainage capacity, elevation risk, live waterlogging level, AI predicted time-to-flood, and mapped potholes with estimated depth in cm).
2. **Hyperlocal Live Weather (`GET /api/weather/:areaSlug`)**
   - Fetches live temperature, humidity, rainfall (`mm/hr`), and wind speed from OpenWeatherMap using each Bengaluru area's exact GPS coordinates (with automatic fallback simulation if no API key is provided).
3. **AI Flood & Pothole Risk Engine (`POST /api/ai/analyze`, `src/services/aiPredictor.js`)**
   - Computes **Estimated Flooding Time (minutes)** based on rainfall intensity (`mm/hr`), street drainage score, terrain slope, and current water level.
   - Estimates **Submerged Pothole Depth (cm)** and **Vehicle Clearance Risk** (Two-Wheeler / Sedan / SUV) when water turbidity hides road craters.
4. **Area-Isolated Live Alerts & Reports (`Socket.IO` + `POST /api/reports`)**
   - When a user selects `"bellandur"` on your frontend, the frontend joins Socket.IO room `area:bellandur`.
   - New citizen reports, pothole detections, or weather spikes in Bellandur broadcast **only** to users currently viewing Bellandur—zero alert spam from Whitefield or HSR!

---

## 3. REST API Endpoints

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Server & DB health check |
| `GET` | `/api/areas` | List all Bengaluru areas (`bellandur`, `hsr-layout`, `whitefield`, etc.) |
| `GET` | `/api/areas/:slug` | Full area dashboard: streets, hotspots, potholes, live weather & recent area reports |
| `GET` | `/api/areas/:slug/streets` | All monitored streets & places inside the selected area |
| `GET` | `/api/weather/:slug` | Current weather + rainfall (`mm/hr`) for the selected area |
| `GET` | `/api/reports/:slug` | Live & verified flood/pothole reports filtered strictly by area |
| `POST` | `/api/reports` | Submit a new flood/pothole report (runs AI calculation + triggers live Socket alert to that area) |
| `POST` | `/api/ai/predict` | Run on-demand AI calculation for flooding time & submerged pothole depth |
| `POST` | `/api/ai/simulate-rain/:slug` | Demo endpoint for viva/presentation: simulates heavy rain in an area & fires live alerts! |

---

## 4. Frontend Integration Guide (React + Socket.IO)

Install `socket.io-client` in your React frontend:
```bash
npm install socket.io-client
```

Example hook in React when user switches area dropdown (e.g., `selectedArea = "bellandur"`):
```javascript
import { useEffect, useState } from "react";
import { io } from "socket.io-client";

const socket = io("http://localhost:5000");

export function useAreaFeed(selectedAreaSlug) {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    if (!selectedAreaSlug) return;

    // Join ONLY the selected area's notification room
    socket.emit("joinArea", selectedAreaSlug);

    const handleNewAlert = (alertPayload) => {
      setAlerts((prev) => [alertPayload, ...prev]);
    };

    socket.on("areaAlert", handleNewAlert);

    return () => {
      socket.emit("leaveArea", selectedAreaSlug);
      socket.off("areaAlert", handleNewAlert);
    };
  }, [selectedAreaSlug]);

  return alerts;
}
```
